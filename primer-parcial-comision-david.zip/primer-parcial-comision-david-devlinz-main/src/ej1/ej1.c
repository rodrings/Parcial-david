#include "../ejs.h"

producto_t *filtrarPublicacionesNuevasDeUsuariosVerificados(catalogo_t *h) {
    return (producto_t *)NULL;
}
