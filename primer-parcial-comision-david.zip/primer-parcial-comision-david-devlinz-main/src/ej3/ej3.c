#include "../ejs.h"
#include <stdint.h>

usuario_t **
asignarNivelesParaNuevosUsuarios(uint32_t *ids, uint32_t cantidadDeIds,
                                 uint8_t (*deQueNivelEs)(uint32_t)) {

  return (usuario_t**) NULL;
}



