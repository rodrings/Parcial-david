#include "../ejs.h"

catalogo_t *removerCopias(catalogo_t *h) {
   return (catalogo_t*)NULL;
}
